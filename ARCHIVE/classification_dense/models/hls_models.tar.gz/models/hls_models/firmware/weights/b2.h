//Numpy array shape [10]
//Min -0.242950439453
//Max 0.715270996094
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const dense_4_bias_t b2[10] = {0.6013794, 0.6080627, 0.7152710, 0.5511780, -0.0235291, -0.2429504, 0.4198914, 0.3955994, -0.1853943, 0.6521606};

#endif
