//Numpy array shape [2]
//Min -0.159790039062
//Max 0.063262939453
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const dense_5_bias_t b4[2] = {-0.1597900, 0.0632629};

#endif
