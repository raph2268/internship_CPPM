//Numpy array shape [2]
//Min -0.065216064453
//Max 0.390686035156
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias7_t b7[2] = {-0.06521606445312, 0.39068603515625};

#endif
