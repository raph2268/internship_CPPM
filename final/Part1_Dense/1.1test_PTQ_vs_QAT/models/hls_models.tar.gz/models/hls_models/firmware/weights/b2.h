//Numpy array shape [8]
//Min -0.348144531250
//Max 0.337890625000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias2_t b2[8] = {0.15527343750, 0.21972656250, -0.08349609375, -0.34814453125, -0.15771484375, 0.17333984375, 0.19384765625, 0.33789062500};

#endif
