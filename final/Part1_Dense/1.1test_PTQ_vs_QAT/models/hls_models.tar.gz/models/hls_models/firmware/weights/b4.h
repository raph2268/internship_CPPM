//Numpy array shape [8]
//Min 0.000000000000
//Max 0.394042968750
//Number of zeros 2

#ifndef B4_H_
#define B4_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias4_t b4[8] = {0.00000000000, 0.11181640625, 0.09375000000, 0.39404296875, 0.08007812500, 0.17578125000, 0.00000000000, 0.02246093750};

#endif
