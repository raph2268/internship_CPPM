//Numpy array shape [1]
//Min -0.065917968750
//Max -0.065917968750
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias6_t b6[1] = {-0.06591796875};

#endif
