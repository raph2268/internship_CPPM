//Numpy array shape [1]
//Min -0.142517089844
//Max -0.142517089844
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias5_t b5[1] = {-0.142517089843750};

#endif
