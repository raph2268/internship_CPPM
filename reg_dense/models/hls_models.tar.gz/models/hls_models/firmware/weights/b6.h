//Numpy array shape [1]
//Min 0.016601562500
//Max 0.016601562500
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias6_t b6[1] = {0.01660156250};

#endif
