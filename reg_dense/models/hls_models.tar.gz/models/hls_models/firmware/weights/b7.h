//Numpy array shape [1]
//Min -0.206298828125
//Max -0.206298828125
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const bias7_t b7[1] = {-0.20629882812500};

#endif
