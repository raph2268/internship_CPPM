//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef B3_H_
#define B3_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const dense_bias_t b3[1] = {0.00};

#endif
