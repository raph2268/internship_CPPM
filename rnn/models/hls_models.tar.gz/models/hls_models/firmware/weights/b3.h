//Numpy array shape [1]
//Min -0.082977689803
//Max -0.082977689803
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const dense_bias_t b3[1] = {-0.08};

#endif
