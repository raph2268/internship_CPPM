//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef BIAS_2_H_
#define BIAS_2_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const simplernn_bias_t bias_2[8] = {0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00};

#endif
