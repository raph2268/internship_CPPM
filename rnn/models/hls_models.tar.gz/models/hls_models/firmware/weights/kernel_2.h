//Numpy array shape [8]
//Min -0.754344940186
//Max 0.658832907677
//Number of zeros 0

#ifndef KERNEL_2_H_
#define KERNEL_2_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const simplernn_weight_t kernel_2[8] = {-0.47, -0.26, -0.63, 0.66, 0.34, -0.75, -0.63, 0.49};

#endif
