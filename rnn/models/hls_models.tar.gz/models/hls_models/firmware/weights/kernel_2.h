//Numpy array shape [8]
//Min -1.453368544579
//Max 1.724148988724
//Number of zeros 0

#ifndef KERNEL_2_H_
#define KERNEL_2_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const simple_rnn_weight_t kernel_2[8] = {-1.45, -0.26, 1.15, 1.65, 0.54, 0.71, 1.72, 0.55};

#endif
