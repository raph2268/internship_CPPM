//Numpy array shape [5]
//Min 0.760173261166
//Max 7.507510185242
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const dense_bias_t b2[5] = {2.9286093711853027344, 5.3453373908996582031, 7.5075101852416992188, 3.8966856002807617188, 0.7601732611656188965};

#endif
