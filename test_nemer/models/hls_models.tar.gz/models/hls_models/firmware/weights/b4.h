//Numpy array shape [1]
//Min 4.020108222961
//Max 4.020108222961
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifdef __INTELFPGA_COMPILER__
hls_init_on_powerup
#endif
static const dense_1_bias_t b4[1] = {4.0201082229614257812};

#endif
